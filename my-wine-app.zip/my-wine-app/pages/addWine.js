// pages/addWine.js
import React, { useState } from 'react';

const AddWinePage = () => {
  const [name, setName] = useState('');
  const [year, setYear] = useState('');
  const [type, setType] = useState('');
  const [varietal, setVarietal] = useState('');
  const [rating, setRating] = useState('');
  const [consumed, setConsumed] = useState(false);
  const [dateConsumed, setDateConsumed] = useState('');
  const [error, setError] = useState('');

  const handleAddWine = async () => {
    try {
      // Basic validation
      if (!name || !year || !type || !varietal) {
        setError('Please fill in all required fields.');
        return;
      }

      // Your actual add wine API endpoint
      const response = await fetch('https://your-api-url/addWine', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name,
          year,
          type,
          varietal,
          rating,
          consumed,
          dateConsumed,
        }),
      });

      // Check if adding wine was successful (you may need to adjust based on your API response)
      if (response.ok) {
        // Successful addition, you can redirect or perform other actions
        console.log('Wine added successfully!');
      } else {
        // Unsuccessful addition, handle errors
        setError('Failed to add wine. Please try again.');
      }
    } catch (error) {
      console.error('Add wine error:', error);
      setError('An unexpected error occurred. Please try again.');
    }
  };

  return (
    <div className="bg-gray-200 min-h-screen flex items-center justify-center">
      <div className="bg-white p-8 rounded shadow-md w-96">
        <h1 className="text-3xl font-bold mb-4">Add a New Wine</h1>
        <form className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">
              Name
            </label>
            <input
              type="text"
              id="name"
              className="mt-1 p-2 w-full border rounded-md"
              placeholder="Wine name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="year" className="block text-sm font-medium text-gray-700">
              Year
            </label>
            <input
              type="number"
              id="year"
              className="mt-1 p-2 w-full border rounded-md"
              placeholder="Year"
              value={year}
              onChange={(e) => setYear(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="type" className="block text-sm font-medium text-gray-700">
              Type
            </label>
            <select
              id="type"
              className="mt-1 p-2 w-full border rounded-md"
              value={type}
              onChange={(e) => setType(e.target.value)}
              required
            >
              <option value="">Select type</option>
              <option value="Red">Red</option>
              <option value="White">White</option>
              <option value="Rosé">Rosé</option>
              <option value="White Blend">White Blend</option>
              <option value="Red Blend">Red Blend</option>
            </select>
          </div>
          <div>
            <label htmlFor="varietal" className="block text-sm font-medium text-gray-700">
              Varietal
            </label>
            <select
              id="varietal"
              className="mt-1 p-2 w-full border rounded-md"
              value={varietal}
              onChange={(e) => setVarietal(e.target.value)}
              required
            >
              <option value="">Select varietal</option>
              <option value="Cabernet Sauvignon">Cabernet Sauvignon</option>
              <option value="Merlot">Merlot</option>
              <option value="Shiraz">Shiraz</option>
              <option value="Chenin Blanc">Chenin Blanc</option>
              <option value="Sauvignon Blanc">Sauvignon Blanc</option>
              <option value="Verdelho">Verdelho</option>
              <option value="Chardonnay">Chardonnay</option>
              <option value="Durif">Durif</option>
            </select>
          </div>
          <div>
            <label htmlFor="rating" className="block text-sm font-medium text-gray-700">
              Rating
            </label>
            <input
              type="number"
              id="rating"
              className="mt-1 p-2 w-full border rounded-md"
              placeholder="Rating (1-5)"
              value={rating}
              onChange={(e) => setRating(e.target.value)}
              min="1"
              max="5"
            />
          </div>
          <div>
            <label htmlFor="consumed" className="block text-sm font-medium text-gray-700">
              Consumed
            </label>
            <input
              type="checkbox"
              id="consumed"
              className="mt-1"
              checked={consumed}
              onChange={(e) => setConsumed(e.target.checked)}
            />
          </div>
          {consumed && (
            <div>
              <label htmlFor="dateConsumed" className="block text-sm font-medium text-gray-700">
                Date Consumed
              </label>
              <input
                type="date"
                id="dateConsumed"
                className="mt-1 p-2 w-full border rounded-md"
                value={dateConsumed}
                onChange={(e) => setDateConsumed(e.target.value)}
                required={consumed}
              />
            </div>
          )}
          {error && <p className="text-red-500">{error}</p>}
          <button
            type="button"
            onClick={handleAddWine}
            className="bg-blue-500 text-white p-2 rounded-md w-full"
          >
            Add Wine
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddWinePage;
