// pages/wineList.js
import React, { useState, useEffect } from 'react';

const WineListPage = () => {
  const [wines, setWines] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch wines from API or database on page load
    const fetchWines = async () => {
      try {
        const response = await fetch('https://your-api-url/getWines');
        if (response.ok) {
          const data = await response.json();
          setWines(data);
        } else {
          setError('Failed to fetch wines. Please try again.');
        }
      } catch (error) {
        console.error('Fetch wines error:', error);
        setError('An unexpected error occurred. Please try again.');
      }
    };

    fetchWines();
  }, []);

  return (
    <div className="bg-gray-200 min-h-screen flex items-center justify-center">
      <div className="bg-white p-8 rounded shadow-md w-96">
        <h1 className="text-3xl font-bold mb-4">My Wines List</h1>
        {error ? (
          <p className="text-red-500">{error}</p>
        ) : (
          <ul className="space-y-2">
            {wines.map((wine) => (
              <li key={wine.id} className="border-b border-gray-300 py-2">
                <strong>{wine.name}</strong> - {wine.year} - {wine.type}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default WineListPage;
