// pages/editWine.js
import React, { useState, useEffect } from 'react';

const EditWinePage = () => {
  const [wineDetails, setWineDetails] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch wine details from your API or database on page load
    const fetchWineDetails = async () => {
      try {
        const response = await fetch('https://your-api-url/getWineDetails/1'); // Replace '1' with the actual wine ID
        if (response.ok) {
          const data = await response.json();
          setWineDetails(data);
        } else {
          setError('Failed to fetch wine details. Please try again.');
        }
      } catch (error) {
        console.error('Fetch wine details error:', error);
        setError('An unexpected error occurred. Please try again.');
      }
    };

    fetchWineDetails();
  }, []);

  const handleEditWine = async () => {
    try {
      // Edit wine API endpoint and logic here
      const response = await fetch('https://your-api-url/editWine/1', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(wineDetails),
      });

      // Check if editing wine was successful (you may need to adjust based on your API response)
      if (response.ok) {
        // Successful edit, you can redirect or perform other actions
        console.log('Wine details edited successfully!');
      } else {
        // Unsuccessful edit, handle errors
        setError('Failed to edit wine details. Please try again.');
      }
    } catch (error) {
      console.error('Edit wine details error:', error);
      setError('An unexpected error occurred. Please try again.');
    }
  };

  return (
    <div className="bg-gray-200 min-h-screen flex items-center justify-center">
      <div className="bg-white p-8 rounded shadow-md w-96">
        <h1 className="text-3xl font-bold mb-4">Edit Wine Details</h1>
        {error ? (
          <p className="text-red-500">{error}</p>
        ) : (
          <form className="space-y-4">
            {/* Edit wine form fields */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Name
              </label>
              <input
                type="text"
                id="name"
                className="mt-1 p-2 w-full border rounded-md"
                placeholder="Wine name"
                value={wineDetails.name || ''}
                onChange={(e) => setWineDetails({ ...wineDetails, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label htmlFor="year" className="block text-sm font-medium text-gray-700">
                Year
              </label>
              <input
                type="number"
                id="year"
                className="mt-1 p-2 w-full border rounded-md"
                placeholder="Year"
                value={wineDetails.year || ''}
                onChange={(e) => setWineDetails({ ...wineDetails, year: e.target.value })}
                required
              />
            </div>
            <div>
              <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                Type
              </label>
              {/* Adjust the options based on use case */}
              <select
                id="type"
                className="mt-1 p-2 w-full border rounded-md"
                value={wineDetails.type || ''}
                onChange={(e) => setWineDetails({ ...wineDetails, type: e.target.value })}
                required
              >
                <option value="">Select type</option>
                <option value="Red">Red</option>
                <option value="White">White</option>
                {/* Add more options as needed */}
              </select>
            </div>
            {/* Repeat similar blocks for other fields */}
            <button
              type="button"
              onClick={handleEditWine}
              className="bg-blue-500 text-white p-2 rounded-md w-full"
            >
              Save Changes
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default EditWinePage;
