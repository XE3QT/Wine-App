// server.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

// Create wine route
app.post('/wines', async (req, res) => {
  const { name, year, type, varietal, rating, consumed, dateConsumed } = req.body;

  try {
    const newWine = await prisma.wine.create({
      data: {
        name,
        year,
        type,
        varietal,
        rating,
        consumed,
        dateConsumed,
      },
    });

    res.status(201).json(newWine);
  } catch (error) {
    console.error('Create wine error:', error);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

// Read all wines route
app.get('/wines', async (req, res) => {
  try {
    const wines = await prisma.wine.findMany();
    res.json(wines);
  } catch (error) {
    console.error('Fetch wines error:', error);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

// Read one wine route
app.get('/wines/:id', async (req, res) => {
  const wineId = parseInt(req.params.id);

  try {
    const wine = await prisma.wine.findUnique({
      where: { id: wineId },
    });

    if (!wine) {
      return res.status(404).json({ error: 'Wine not found' });
    }

    res.json(wine);
  } catch (error) {
    console.error('Fetch wine error:', error);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

// Update wine route
app.put('/wines/:id', async (req, res) => {
  const wineId = parseInt(req.params.id);
  const { name, year, type, varietal, rating, consumed, dateConsumed } = req.body;

  try {
    const updatedWine = await prisma.wine.update({
      where: { id: wineId },
      data: {
        name,
        year,
        type,
        varietal,
        rating,
        consumed,
        dateConsumed,
      },
    });

    res.status(200).json(updatedWine);
  } catch (error) {
    console.error('Update wine error:', error);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

// Delete wine route
app.delete('/wines/:id', async (req, res) => {
  const wineId = parseInt(req.params.id);

  try {
    await prisma.wine.delete({
      where: { id: wineId },
    });

    res.status(204).send(); // No content
  } catch (error) {
    console.error('Delete wine error:', error);
    res.status(500).json({ error: 'An unexpected error occurred' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
